sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ae.add.adnoc.vendorportal.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  